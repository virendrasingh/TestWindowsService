﻿using System;
using System.Data.SqlClient;
using System.Diagnostics;
using System.Net.Mail;
using System.ServiceProcess;
using System.Timers;
using System.Configuration;

namespace EmailNotification
{
    public partial class Service1 : ServiceBase
    {
        public Service1()
        {
            LogService.Entry(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType.Name, 
                             System.Reflection.MethodBase.GetCurrentMethod().Name);
            InitializeComponent();
        }
        private static Timer ApprovalReminderTimer;
        private static Timer SLATimer;
        private static Timer PmTimer;

        protected override void OnStart(string[] args)
        {
            LogService.Entry(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType.Name, System.Reflection.MethodBase.GetCurrentMethod().Name);
            eventLog1.Source = "Application";
            eventLog1.WriteEntry("Started", EventLogEntryType.Information, 101, 1);
            ExpenseEmail();
            SLAEmail();
            PMEmail();
        }

        private void ExpenseEmail()
        {
            LogService.Entry(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType.Name,
                             System.Reflection.MethodBase.GetCurrentMethod().Name);

            string ExpenseEmailDurationConfig = ConfigurationManager.AppSettings["ExpenseEmailDuration"];
            ApprovalReminderTimer = new Timer(TimeSpan.FromHours(int.Parse(ExpenseEmailDurationConfig)).TotalMilliseconds);
            // Hook up the Elapsed event for the timer. 
            ApprovalReminderTimer.Elapsed += new ElapsedEventHandler(SendApprovalEmail);
            // Have the timer fire repeated events (true is the default)
            ApprovalReminderTimer.AutoReset = true;
            // Start the timer
            ApprovalReminderTimer.Enabled = true;
            LogService.Exit(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType.Name, System.Reflection.MethodBase.GetCurrentMethod().Name);

        }
        
        private void SLAEmail()
        {
            LogService.Entry(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType.Name, 
                              System.Reflection.MethodBase.GetCurrentMethod().Name);

           
            string ExpenseEmailDurationConfig = ConfigurationManager.AppSettings["ExpenseEmailDuration"];
            SLATimer = new Timer();
            SLATimer.Interval = double.Parse(ExpenseEmailDurationConfig);
            // Hook up the Elapsed event for the timer. 
            SLATimer.Elapsed += new ElapsedEventHandler(SendSLACountEmail);
            // Have the timer fire repeated events (true is the default)
            SLATimer.AutoReset = true;
            // Start the timer
            SLATimer.Enabled = true;
            LogService.Exit(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType.Name, 
                            System.Reflection.MethodBase.GetCurrentMethod().Name);

        }

        private void PMEmail()
        {
            LogService.Entry(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType.Name,
                             System.Reflection.MethodBase.GetCurrentMethod().Name);

            string ExpenseEmailDurationConfig = ConfigurationManager.AppSettings["PMAdvanceAlertTimerconfigvalue"];
            PmTimer = new Timer(TimeSpan.FromHours(int.Parse(ExpenseEmailDurationConfig)).TotalMilliseconds);
            // Hook up the Elapsed event for the timer. 
            PmTimer.Elapsed += new ElapsedEventHandler(SendPMEmail);
            // Have the timer fire repeated events (true is the default)
            PmTimer.AutoReset = true;
            // Start the timer
            PmTimer.Enabled = true;
            LogService.Exit(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType.Name, 
                            System.Reflection.MethodBase.GetCurrentMethod().Name);

        }

        private void SendApprovalEmail(object sender, ElapsedEventArgs e)
        {
            LogService.Entry(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType.Name, System.Reflection.MethodBase.GetCurrentMethod().Name);
            //Code to send email for expense Approval

            LogService.Exit(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType.Name, System.Reflection.MethodBase.GetCurrentMethod().Name);
        }


        private void SendPMEmail(object sender, ElapsedEventArgs e)
        {
            LogService.Entry(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType.Name, 
                             System.Reflection.MethodBase.GetCurrentMethod().Name);
            //Code to send email for PM Ending Notification
            LogService.Exit(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType.Name,
                            System.Reflection.MethodBase.GetCurrentMethod().Name);

        }

        private void SendSLACountEmail(object sender, ElapsedEventArgs e)
        {
            LogService.Entry(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType.Name,
                             System.Reflection.MethodBase.GetCurrentMethod().Name);
            //Code to send email for SLA Count Notification
            LogService.Exit(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType.Name,
                            System.Reflection.MethodBase.GetCurrentMethod().Name);
        }

        protected override void OnStop()
        {
            LogService.Exit(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType.Name, System.Reflection.MethodBase.GetCurrentMethod().Name);
        }

     

        private static void SendSLACount()
        {
            string ConnectString = ConfigurationManager.AppSettings["ConnectString"];
            LogService.Entry(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType.Name, System.Reflection.MethodBase.GetCurrentMethod().Name);
            SqlConnection connect = new SqlConnection(ConnectString);
            try
            {
                string SMTPClient, FromMail, ToMail, EmailSubject, UserName, Passowrd, ExpenseQuery;
                int portNo = Convert.ToInt32(ConfigurationManager.AppSettings["PortNo"]);
                SMTPClient = ConfigurationManager.AppSettings["SMTPClient"];
                FromMail = ConfigurationManager.AppSettings["FromMail"];
                ToMail = ConfigurationManager.AppSettings["ToMain"];
                EmailSubject = ConfigurationManager.AppSettings["EmailSubject"];
                UserName = ConfigurationManager.AppSettings["UserName"];
                Passowrd = ConfigurationManager.AppSettings["Passowrd"];
                ExpenseQuery = ConfigurationManager.AppSettings["ExpenseQuery"];
                string line = "";
                connect.Open();
                SqlCommand GetData = new SqlCommand(ExpenseQuery, connect);
                SqlDataReader ReadData = null;
                ReadData = GetData.ExecuteReader();
                while (ReadData.Read())
                {
                    line = ReadData[0].ToString();
                }
                connect.Close();
                if (double.Parse(line) > 0)
                {
                    MailMessage mail = new MailMessage();
                    SmtpClient smtpserver = new SmtpClient(SMTPClient);
                    mail.From = new MailAddress(FromMail);
                    mail.To.Add(ToMail);
                    mail.Subject = EmailSubject;
                    mail.Body = line;
                    smtpserver.Port = portNo;//587;
                    smtpserver.Credentials = new System.Net.NetworkCredential(UserName, Passowrd);
                    smtpserver.EnableSsl = true;
                    smtpserver.Send(mail);

                }
            }
            catch (Exception ex)
            {
                LogService.Error(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType.Name, System.Reflection.MethodBase.GetCurrentMethod().Name, Convert.ToString(ex));
            }
            finally
            {
                connect.Close();
                LogService.Exit(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType.Name, System.Reflection.MethodBase.GetCurrentMethod().Name);
            }
        }

        public static void SendEMailExpense()
        {
            string ConnectString= ConfigurationManager.AppSettings["ConnectString"];
            LogService.Entry(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType.Name, System.Reflection.MethodBase.GetCurrentMethod().Name);
            SqlConnection connect = new SqlConnection(ConnectString);
            try
            {
                string SMTPClient, FromMail, ToMail, EmailSubject,UserName, Passowrd, ExpenseQuery;
                int portNo=Convert.ToInt32(ConfigurationManager.AppSettings["PortNo"]);
                SMTPClient = ConfigurationManager.AppSettings["SMTPClient"];
                FromMail = ConfigurationManager.AppSettings["FromMail"];
                ToMail= ConfigurationManager.AppSettings["ToMain"];
                EmailSubject = ConfigurationManager.AppSettings["EmailSubject"];
                UserName = ConfigurationManager.AppSettings["UserName"];
                Passowrd = ConfigurationManager.AppSettings["Passowrd"];
                ExpenseQuery = ConfigurationManager.AppSettings["ExpenseQuery"];
                string line = "";
                connect.Open();
                SqlCommand GetData = new SqlCommand(ExpenseQuery, connect);
                SqlDataReader ReadData = null;
                ReadData = GetData.ExecuteReader();
                while (ReadData.Read())
                {
                    line = ReadData[0].ToString();
                }
                connect.Close();
                if (double.Parse(line) > 0)
                {
                    MailMessage mail = new MailMessage();
                    SmtpClient smtpserver = new SmtpClient(SMTPClient);
                    mail.From = new MailAddress(FromMail);
                    mail.To.Add(ToMail);
                    mail.Subject = EmailSubject;
                    mail.Body = "<HTML><HEAD><TITLE>expense Pending for Approval</TITLE></HEAD></HTML>";
                    smtpserver.Port = portNo;//587;
                    smtpserver.Credentials = new System.Net.NetworkCredential(UserName, Passowrd);
                    smtpserver.EnableSsl = true;
                    smtpserver.Send(mail);
                    
                }
            }
            catch (Exception ex)
            {
                LogService.Error(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType.Name, System.Reflection.MethodBase.GetCurrentMethod().Name, Convert.ToString(ex));
            }
            finally
            {
                connect.Close();
                LogService.Exit(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType.Name, System.Reflection.MethodBase.GetCurrentMethod().Name);
            }
        }


        public static void SendEmailForApprovalReminder()
        {

            LogService.Entry(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType.Name,
                             System.Reflection.MethodBase.GetCurrentMethod().Name);
            ///Code need to be added here
            LogService.Exit(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType.Name,
                            System.Reflection.MethodBase.GetCurrentMethod().Name);
        }


    }
}
