﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;

namespace EmailNotification
{
    class LogService
    {
        private static readonly log4net.ILog log = Loghelper.GetLogger();
        public static void Entry(string Class, string Function)
        {
            log.Info("Entry:-" + Class + "/" + Function);
        }
        public static void Exit(string Class, string Function)
        {
            log.Info("Exit:-" + Class + "/" + Function);
        }
        public static void Error(string Class, string Function, string Error)
        {
            log.Error("Error:-" + Class + "/" + Function + "  :  Error is :-" + Error);
        }
    }
    public class Loghelper
    {
        public static log4net.ILog GetLogger([CallerFilePath]string filename = "")
        {
            return log4net.LogManager.GetLogger(filename);
        }
    }
}
